﻿namespace CAL_MIDTERM_PROJECT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.start_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Countdownlabel = new System.Windows.Forms.Label();
            this.ScoreTextbox = new System.Windows.Forms.Label();
            this.quit_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.stop_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // start_button
            // 
            this.start_button.BackColor = System.Drawing.Color.YellowGreen;
            this.start_button.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.start_button.Location = new System.Drawing.Point(483, 542);
            this.start_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.start_button.Name = "start_button";
            this.start_button.Size = new System.Drawing.Size(164, 38);
            this.start_button.TabIndex = 0;
            this.start_button.Text = "START";
            this.start_button.UseVisualStyleBackColor = false;
            this.start_button.Click += new System.EventHandler(this.start_button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.5F);
            this.label1.Location = new System.Drawing.Point(240, 95);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 42);
            this.label1.TabIndex = 5;
            this.label1.Text = "TIME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.5F);
            this.label2.Location = new System.Drawing.Point(687, 95);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 42);
            this.label2.TabIndex = 6;
            this.label2.Text = "SCORE";
            // 
            // Countdownlabel
            // 
            this.Countdownlabel.AutoSize = true;
            this.Countdownlabel.BackColor = System.Drawing.Color.Snow;
            this.Countdownlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Countdownlabel.Location = new System.Drawing.Point(255, 149);
            this.Countdownlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Countdownlabel.Name = "Countdownlabel";
            this.Countdownlabel.Size = new System.Drawing.Size(76, 29);
            this.Countdownlabel.TabIndex = 7;
            this.Countdownlabel.Text = "00:15";
            // 
            // ScoreTextbox
            // 
            this.ScoreTextbox.AutoSize = true;
            this.ScoreTextbox.BackColor = System.Drawing.Color.Snow;
            this.ScoreTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScoreTextbox.Location = new System.Drawing.Point(738, 147);
            this.ScoreTextbox.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ScoreTextbox.Name = "ScoreTextbox";
            this.ScoreTextbox.Size = new System.Drawing.Size(43, 30);
            this.ScoreTextbox.TabIndex = 8;
            this.ScoreTextbox.Text = "00";
            // 
            // quit_button
            // 
            this.quit_button.BackColor = System.Drawing.Color.Yellow;
            this.quit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F);
            this.quit_button.Location = new System.Drawing.Point(756, 537);
            this.quit_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.quit_button.Name = "quit_button";
            this.quit_button.Size = new System.Drawing.Size(130, 43);
            this.quit_button.TabIndex = 10;
            this.quit_button.Text = "Reset";
            this.quit_button.UseVisualStyleBackColor = false;
            this.quit_button.Click += new System.EventHandler(this.quit_button_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CAL_MIDTERM_PROJECT.Properties.Resources.pngwing_com;
            this.pictureBox1.Location = new System.Drawing.Point(431, 187);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(231, 177);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // stop_button
            // 
            this.stop_button.Location = new System.Drawing.Point(272, 547);
            this.stop_button.Name = "stop_button";
            this.stop_button.Size = new System.Drawing.Size(86, 27);
            this.stop_button.TabIndex = 16;
            this.stop_button.Text = "QUIT";
            this.stop_button.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackgroundImage = global::CAL_MIDTERM_PROJECT.Properties.Resources.images;
            this.ClientSize = new System.Drawing.Size(1198, 612);
            this.Controls.Add(this.stop_button);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.quit_button);
            this.Controls.Add(this.ScoreTextbox);
            this.Controls.Add(this.Countdownlabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.start_button);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button start_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Countdownlabel;
        private System.Windows.Forms.Label ScoreTextbox;
        private System.Windows.Forms.Button quit_button;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button stop_button;
    }
}

