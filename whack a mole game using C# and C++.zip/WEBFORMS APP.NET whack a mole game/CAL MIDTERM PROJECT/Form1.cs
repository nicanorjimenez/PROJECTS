﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Media;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using NAudio.Wave;






namespace CAL_MIDTERM_PROJECT
{
    public partial class Form1 : Form
    {
        private int countdownDuration = 15; // Duration in seconds
        private bool countdownRunning = false;
        private bool gameRunning = false;
        private int score = 0;
        private SerialPort arduinoPort;
        private bool resetRequested = false;
        private IWavePlayer waveOutDevice;
        private AudioFileReader audioFile;
        private bool isButtonPressed = false;
        private static int score1 = 0;





        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(this.Form1_Load);
            this.FormClosing += new FormClosingEventHandler(this.Form1_FormClosing);
        }

        private void StartMusic()
        {
            waveOutDevice = new WaveOutEvent();
            audioFile = new AudioFileReader(@"C:\Users\hp\source\repos\CAL MIDTERM PROJECT\myleg.mp3");
            waveOutDevice.Init(audioFile);
            waveOutDevice.Play();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ConnectToArduino();
            Countdownlabel.Text = "00:15";
            string filePath = @"C:\Users\hp\source\repos\CAL MIDTERM PROJECT\bgmusic.mp3";
            
            waveOutDevice = new WaveOutEvent();
            audioFile = new AudioFileReader(filePath);

            waveOutDevice.Init(audioFile);
            waveOutDevice.Play();
        }

        private void StartCountdown()
        {
            if (!countdownRunning && !gameRunning)
            {
                countdownRunning = true;
                gameRunning = true; // Mark game as running
                ThreadPool.QueueUserWorkItem(CountdownThread);
            }
        }

        private void CountdownThread(object state)
        {
            int remainingTime = countdownDuration;
            while (remainingTime >= 0 && !resetRequested && gameRunning)
            {
                if (InvokeRequired)
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        Countdownlabel.Text = $"00:{remainingTime:D2}";
                    });
                }
                Thread.Sleep(1000);
                remainingTime--;
            }

            if (resetRequested)
            {
                resetRequested = false; // Reset the flag
            }
            else if (gameRunning)
            {
                EndGame();
            }

        }

        private void EndGame()
        {
            countdownRunning = false;
            gameRunning = false;
            MessageBox.Show("Game Over! Your final score is: " + score);
            isButtonPressed = false; // Reset the button state

            if (arduinoPort.IsOpen)
            {
                // Send the 'E' signal to activate the buzzer when the timer hits zero
                arduinoPort.Write("E");
            }

        }

        public class ScoreManager
        {
            private static int score = 0;

            public static int GetScore()
            {
                return score;
            }

            public static void IncreaseScoreByTen()
            {
                score += 10;
            }

            public static void ResetScore()
            {
                score = 0;
            }
        }

        private void ButtonPressed() // Simulates a button press event
        {
            int currentScore = ScoreManager.GetScore();
            ScoreManager.IncreaseScoreByTen();
            isButtonPressed = true;
            score += 10; // Increase the score by 10 (you can adjust the score increment as needed)
            UpdateScoreTextbox();
            Console.WriteLine("Button pressed");




            if (arduinoPort.IsOpen)
            {
                string receivedData = arduinoPort.ReadExisting();
                if (receivedData.Contains("B"))
                {
                    // Handle the case when "B" is received
                    // You can add more logic here based on your requirements
                }
            }
        }


        private void UpdateScoreTextbox()
        {
            int currentScore = ScoreManager.GetScore();

            if (InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate
                {
                    ScoreTextbox.Text = currentScore.ToString();
                });
            }
            else
            {
                ScoreTextbox.Text = currentScore.ToString();
            }

            StartMusic();
        }

        private void ArduinoDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string inData = arduinoPort.ReadLine();

            if (inData.Contains("B"))
            {
                // Button signal received from Arduino
                ButtonPressed();
                UpdateScoreTextbox();
            }
        }

        private void start_button_Click(object sender, EventArgs e)
        {
            if (arduinoPort != null && arduinoPort.IsOpen)
            {
                try
                {
                    arduinoPort.Write("S"); // Sending the 'S' signal to start the game
                    StartCountdown();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error writing to the serial port: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Connect to Arduino first!");
                // Handle the situation when the Arduino is not connected
            }
        }



        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DisconnectFromArduino();
            waveOutDevice?.Dispose();
            audioFile?.Dispose();
        }

        private void ResetGame()
        {
            ScoreManager.ResetScore();
            resetRequested = true; // Set the reset flag to stop the countdown
            gameRunning = true;
            UpdateScoreTextbox();
            ResetTimerLabel();

            if (arduinoPort.IsOpen)
            {
                arduinoPort.Write("E"); // Sending the 'E' signal to indicate game reset
                Thread.Sleep(500); // Adjust the delay based on your requirements
                arduinoPort.DiscardInBuffer(); // Clear the input buffer to avoid processing old 'B' signals
            }

            resetRequested = false; // Reset the flag after processing the reset
        }


        private void ResetTimerLabel()
        {
            Countdownlabel.Text = "00:15";
        }



        private void reset_button_Click_1(object sender, EventArgs e)
        {
            ResetGame();

            if (arduinoPort.IsOpen)
            {
                arduinoPort.Write("E"); // Sending the 'E' signal to indicate game reset
            }
        }

        private void QuitGame()
        {
            countdownRunning = false;
            gameRunning = false;
            score = 0;
            UpdateScoreTextbox();
            ResetTimerLabel();


        }

        private void quit_button_Click(object sender, EventArgs e)
        {
            if (gameRunning)
            {
                QuitGame();
            }
        }

        private void ConnectToArduino()
        {
            arduinoPort = new SerialPort("COM6", 9600);

            arduinoPort.DataReceived += new SerialDataReceivedEventHandler(ArduinoDataReceived);

            try
            {
                arduinoPort.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening serial port: " + ex.Message);
            }
        }

        private void DisconnectFromArduino()
        {
            if (arduinoPort != null && arduinoPort.IsOpen)
            {
                arduinoPort.Close();
            }
        }

        private void connect_button_Click(object sender, EventArgs e)
        {
            ConnectToArduino();
        }

        private void disconnect_button_Click(object sender, EventArgs e)
        {
            DisconnectFromArduino();
        }


    }




}
