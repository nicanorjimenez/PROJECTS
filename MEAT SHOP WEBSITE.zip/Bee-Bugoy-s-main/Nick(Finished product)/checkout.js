let btn = document.querySelector('.btn');

btn.addEventListener("click", function(){
    document.location.href = 'Thank-You.html';
});