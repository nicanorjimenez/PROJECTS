function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
}

function toggleChatBox() {
    var chatBox = document.getElementById('message-container');
    chatBox.style.display = chatBox.style.display === 'none' ? 'block' : 'none';
}

function sendMessage() {
    var inputMessage = document.getElementById('input-message').value;

    if (inputMessage.trim() !== '') {
        var messageContainer = document.getElementById('message-container');
        var message = document.createElement('p');
        message.textContent = inputMessage;
        messageContainer.appendChild(message);
        document.getElementById('input-message').value = '';
    }
}

function toggleSearchBar() {
    var searchBar = document.querySelector('.search-container');
    searchBar.style.display = searchBar.style.display === 'none' ? 'flex' : 'none';
}

function search() {
    // Add your search functionality here
    alert('Search functionality will be implemented here.');
}

function openStylingTipsModal() {
    var modal = document.getElementById('styling-tips-modal');
    modal.style.display = 'block';
}

function closeModal() {
    var modal = document.getElementById('styling-tips-modal');
    modal.style.display = 'none';
}
